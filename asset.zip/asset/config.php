<?php 
error_reporting(E_ALL & ~E_DEPRECATED);
$config = array(
    "database_type"=>"mysql",
    "database_name"=>"dbtrack",
    "server"=>"localhost",
    "username"=>"root",
    "password"=>"",
    "charset"=>"utf8",
    "port"=>3306,
    "encryption_key"=>"e63ab8bc9d446ea6be0f75261528a8ea7f8aa3be97c2436d3abb53931211701c" ); ?>